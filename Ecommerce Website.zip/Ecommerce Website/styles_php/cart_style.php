<style>
    .cart-img {
        object-fit: contain;
    }
    h2 {
        font-family: "Poppins", sans-serif;
        font-size: 50px;
        color: red;
    }
    .center-continue-shopping {
        display: block;
        margin: 20px auto 0;
        text-align: center;
        padding: 10px 20px;
        background-color: #17a2b8;
        border: none;
        color: white;
        font-size: 16px;
        border-radius: 5px;
        text-decoration: none;
    }
</style>