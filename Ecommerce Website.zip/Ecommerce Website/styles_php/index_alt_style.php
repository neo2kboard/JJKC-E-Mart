<style>
    .no-stock-message,
    .no-product-message {
        font-family: 'Poppins', sans-serif;
        font-size: 40px; 
        margin-left: 120px;
        font-weight: bold; 
    }
    
</style>