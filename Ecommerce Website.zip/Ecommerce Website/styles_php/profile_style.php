<style>
    .profile_img {
        width: 90%;
        height: 90%;
        object-fit: contain;
        margin: auto;
        display: block;
    }
    h4 {
        font-size: 18px;
        font-family: "Poppins", sans-serif;
    }

    .pending-orders {
        font-family: 'Poppins', sans-serif; 
        font-size: 28px; 
        color: #006400; 
        font-weight: 600; 
        text-align: center; 
        margin-top: 20px;
    }
    .order_det {
        font-family: 'Poppins', sans-serif; 
        font-size: 20px;
    }

</style>