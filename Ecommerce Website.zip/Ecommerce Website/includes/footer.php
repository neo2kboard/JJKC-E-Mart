<div class="bg-success p-3 text-center">
        <p>Choose what suits your taste!</p>
</div>